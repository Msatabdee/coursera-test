A Pen created at CodePen.io. You can find this one at http://codepen.io/tutsplus/pen/VvZXMP.

 

Forked from [George](http://codepen.io/georgemarts/)'s Pen [JdNKBL](http://codepen.io/georgemarts/pen/JdNKBL/).